#!/bin/bash

echo "Ashu : What is your name"
echo "Rahul : My name is Rahul"
echo "Ashu : How are you"
echo "Rahul : I'm doing good, Thanks you"
