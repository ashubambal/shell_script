#!/bin/bash

dir=/home/ubuntu/DevOps/Scripts/*.sh

for files in $dir
do
	echo $files
done
