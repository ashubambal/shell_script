#!/bin/bash

name=2
n='as'

if [ $n == 'ash' ]
then
	echo "Yes, Ashu logon"
else
	echo "val is diff"
fi
