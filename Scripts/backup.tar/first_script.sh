#!/bin/bash


echo "Hello, Good Morning"

echo "My name is Ashutosh"

echo "How are you doing tody"

echo "I am doing great today's date is " && date | awk '{print $1,$2,$3}'

echo "meri ram full ho gayi hai " && free -h
