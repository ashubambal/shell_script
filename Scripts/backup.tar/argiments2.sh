#!/bin/bash

echo "$@"
echo "agrumrnt count : $#"
