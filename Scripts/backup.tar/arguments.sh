#!/bin/bash

echo "This is $1"

