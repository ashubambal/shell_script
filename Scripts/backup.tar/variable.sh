#!/bin/bash

name="Ashutosh Kale"

echo "My name is $name"

echo "What is your channel name"

read channl

echo "do subscribe $channl"
