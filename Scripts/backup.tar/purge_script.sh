#!/bin/bash

sudo apt purge $1

